import { Link } from "react-router-dom";

function Home() {
    return (
      <div>
        <h1>This is the home page</h1>
        <Link to="about">about page</Link>
        <Link to="contact" style={{'marginLeft':'30px'}}>contact page</Link>
        <Link to="userform" style={{'marginLeft':'30px'}}>User Form</Link>
        
      </div>
    );
  }
  
  export default Home;